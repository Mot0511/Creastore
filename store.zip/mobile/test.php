<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
      h1{
        color: blue
      }
      @media (max-width: 1000px){
        h1{
          color: red;
        }
      }
    </style>
  </head>
  <body>
    <h1>Test</h1>
  </body>
</html>
